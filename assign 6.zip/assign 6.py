print("Welcome to the Grade Sorter App")
grades=[]
grade1=input("what is your first grade(0-100):")
grade2=input("what is your second grade(0-100):")
grade3=input("what is your third grade(0-100):")
grade4=input("what is your fourth grade(0-100):")

print(f"Your grades are:[{grade1},{grade2},{grade3},{grade4}"])

grades.append(grade1)
grades.append(grade2)
grades.append(grade3)
grades.append(grade4)
grades.sort(reverse=True)
 

print("Your grades from highest to lowest are:",grades)
